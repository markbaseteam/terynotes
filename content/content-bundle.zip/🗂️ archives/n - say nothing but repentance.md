When we teach nothing but [[n - he rejoices when we repent|repentance]], it means we focus on preaching the gospel "which is the gospel of repentance and salvation through the mercy, grace, and merits of the Lord Jesus Christ."

>9 Say nothing but repentance unto this generation; keep my commandments, and assist to bring forth my work, according to my commandments, and you shall be blessed. 

---
Copies:
Source: Doctrine and Covenants 6:9, 11:9, Doctrine and Covenants Student Manual 11
Tags: #repentance #lordswork #scriptures/commandments #mercy #grace #atonement #Jesus_Christ 