- [[life is predictive]]
- [[the two motivations of human behavior]]
- [[mastering the skill of showing up]]
- [[using environment design to accomplish goals]]
- [[we are products of our environment]]
- [[n - emotions allow us to make decisions]]

