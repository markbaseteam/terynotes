>In our current moment in which casual conversations in the hallway or impromptu office visits are impossible, you have to be using meeting scheduling services that allow people to select a time from your list of available times. Use calend.ly, use Acuity, use the features built into Microsoft Outlook,  and if you’re setting up a group meeting, use Doodle. But do not let this coordination unfold as a slow back-and-forth exchange of messages, as this is guaranteed to keep you in a state of constant, agitated inbox checking.

---
Copies: https://hypothes.is/a/w4h4AAO2Ee6cxyeJW-IBTA
Tags: #calendar/blocking #scheduling #meetings 