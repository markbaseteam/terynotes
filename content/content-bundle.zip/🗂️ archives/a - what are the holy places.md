> Sister Ann M. Dibb, who served as a Counselor in the Young Women General Presidency, explained how we can stand in holy places: “President Ezra Taft Benson counseled, ‘Holy places include our temples, our chapels, our homes, and the stakes of Zion, which are … “for a defense, and for a refuge’’ [D&C 115:6]’ [‘Prepare Yourself for the Great Day of the Lord,’ New Era, May 1982, 50]. In addition to these, I believe we can each find many more places. We might first consider the word place as a physical environment or a geographic location. However, a place can be ‘a distinct condition, position, or state of mind’ [Merriam-Webster Online, ‘place,’ merriam-webster.com/dictionary/place]. This means holy places can also include moments in time—moments when the Holy Ghost testifies to us, moments when we feel Heavenly Father’s love, or moments when we receive an answer to our prayers. Even more, I believe any time you have the courage to stand for what is right, especially in situations where no one else is willing to do so, you are creating a holy place” (“Your Holy Places,” Ensign or Liahona, May 2013, 115).

great points here:

- physical holy places are: temples, chapels and homes
- intangible holy places are: moments we are in companionship of his spirit

the common denominator being: whenever we act outside of our natural inclinations (or our natural man), we enter a place of safety. when our eternal selves (spiritual man) is in domination, we are in a safe place

---
Copies: https://hypothes.is/a/0xGkbARIEe6VRfMdWyrCqQ
Tags: #human/spiritual #holy/places #holy/ghost #human/natural
