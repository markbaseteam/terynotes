alice approaches a fork in the road and asks the cheshire cat which way to go. 

the cheshire cat asks where she's going, and she replies "I don't know," to then the cat says, "then it doesn't matter."

---
Copies:
Source: Alice in the Wonderland
Tags: #decision/making #goal-setting #choice