>*Learning does not happen in a vacuum. It is influenced by social dynamics, most notably between students and their peers.*

this reminds me of the [[n - the whiteboard effect and collaborative deep work|"whiteboard effect" and the concept of collaborative learning]] as described by [[b - Deep Work - Cal Newport|cal newport in his book, deep work]].

such dynamics cultivate a culture of fortuitous learning and the exchange of ideas. when another individual is present, it instills a sense of accountability and motivation to dive profoundly into a problem and the gaps of each other's knowledge than we might when woking in solitude.

---
Copies: https://hypothes.is/a/pGA2FAFgEe63GVcsZjoCyA
Tags: #learning #environment/influence #collaboration #knowledge #sense-making 