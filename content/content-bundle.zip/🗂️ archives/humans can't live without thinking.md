>humans are addicted to solving problems through thinking...humans can't meditate. 

Source:  [Yoshin David Radin from DTFH 529](https://open.spotify.com/episode/21uLTR4tZLSPEPpCGdE3iU?si=2f8ed328061a4531)
Tags: #thinking #meditation #thoughts #problem/solving 