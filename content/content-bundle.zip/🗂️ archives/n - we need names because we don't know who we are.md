“What's your name,' Coraline asked the cat. 'Look, I'm Coraline. Okay?'  

'Cats don't have names,' it said.  

'No?' said Coraline.  

'No,' said the cat. 'Now you people have names. That's because you don't know who you are. We know who we are, so we don't need names.”  

---
Copies: 
Source: Neil Gaiman, [Coraline](https://www.goodreads.com/work/quotes/2834844)
Tags: #identity #name #label #human 