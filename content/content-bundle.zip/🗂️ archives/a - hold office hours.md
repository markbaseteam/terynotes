> Setup a recurring Zoom meeting for set times every week where you guarantee to be present. As much as possible, when people send you an ambiguous request or initiate a conversation that will require a lot of back and forth, point them toward your office hours schedule and tell them to stop by next time they can to discuss. It’s a simple idea, but it can reduce the number of attention-snagging back-and-forth electronic messages in your professional life by an order of magnitude.

---
Copies: https://hypothes.is/a/ffx3fAO3Ee6FfDfopSCaIg
Tags: #office-hours #time/management  #email/management/inbox-zero 