collaborative deep work, where two or more people work together to solve a problem, can be highly effective in certain contexts. [[open workspace and serendipitous learning|the presence of another person can provide accountability and motivation to delve deeper into a problem than one might do alone.]] this is referred to as the "[[leveraging the whiteboard effect for deep thinking|whiteboard effect]]" by cal newport.

---
Copies:
Source: [[b - Deep Work - Cal Newport]] pg 79
Tags: #collaboration #whiteboard #teamwork #creativity #ideation #accountability #motivation #problem/solving 

