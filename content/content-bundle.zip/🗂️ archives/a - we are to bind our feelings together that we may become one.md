> “We must understand that we have got to act upon certain principles by which we can bind ourselves together as a people, to bind our feelings together that we may become one, and this never can be accomplished unless certain things are done, and things that require an exertion on our part. “How would you go to work to bind yourselves together? How would a man go to work to unite himself with his neighbor? If two men were associated together who had never been acquainted, how would they go to work to secure each other’s friendship, attachment and affection one towards another? Why something would have to be done, and that not by one party only, but would have to be done by one as well as by the other. It would not answer for one to do the business alone; it would not do for one to answer those feelings and do the work himself, but in order to become as one in their sentiments and affection—the action of both would be requisite” (Teachings of Presidents of the Church: Lorenzo Snow [2012] 198–99).

- this sheds a light on how the church becomes a unified entity, encompassing not only shared objectives and principles, but also a profound sense of interconnectedness on an emotional level. [[n - emotions allow us to make decisions]]
- elder d todd christofferson instructs that a sense of belonging arises not only from being a member of a group but also from the acts of service and sacrifices made for others
- such a complex and tightly-knit community can only be established when it is driven by a higher purpose. when too much emphasis is placed on personal needs and comfort, it can impede the sense of belonging that arises from contributing to a cause greater than oneself

[[n - much of our belonging comes from our contributions]]

---
Copies: https://hypothes.is/a/J5uFQARCEe6057O_1HJ9Ow
Tags: #zion #unity #belongingness #religion/lds/church #mind/emotional
