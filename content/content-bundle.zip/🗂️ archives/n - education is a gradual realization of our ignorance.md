>Education is a gradual realization of our own ignorance. The expansion of one's awareness of of one's own ignorance as one learns ensures that the educated person remains humble about knowledge and understanding.

---
Copies:
Source: [[Everybody is Ignorant, Only on Different Subjects]]
Tags: #ignorance #education #knowledge #learning #awareness #humility #understanding 