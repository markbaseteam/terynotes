>*Student engagement is one of the strongest leading indicators we have of positive learning outcomes. Consequently, when students are disengaged, they are less likely to achieve their learning goals.*

---
Copies: https://hypothes.is/a/cKiVagFfEe6uGtfd06uQFQ
Tags: #learning #engagement #goal-setting #interest