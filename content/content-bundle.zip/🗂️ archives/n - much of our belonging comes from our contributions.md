Elder D. Todd Christofferson teaches the [[zion's core is the sense of belongingness|importance of personal contributions to the sense of belonging]]. Belonging not only comes from being part of a group, but also from the [[let us minister and be ministered|service and sacrifices]] made for others and for a [[people gathered together to exalt god|higher purpose]]. It suggests that [[those who belonged to the church prospered|focusing too much on personal needs and comfort]] can actually hinder the feeling of belonging that comes from [[priestcraft is preaching the gospel for selfish purposes|contributing to something greater than oneself]]. Thus, a sense of belonging is not just a passive experience but requires active participation and contribution.

---
Copies:
Source: [[The Doctrine of Belonging - Elder D. Todd Christofferson]]
Tags: #contribution #commitment #community #zion #belongingness #service #sacrifice #purpose/higher #self/centricness #active #participation 