I'm currently in a hole where [Savannah Brown](https://www.youtube.com/@savbrown) and [Evan Dahm](https://www.youtube.com/@evndahm) are fueling my thinking organ to do the thing it's supposed to be doing. And this [video](https://youtu.be/mPXLP9mYRi4) had got me thinking about the malleability of identity and the instances in our timeline in which these changes actually manifest.

# people change
When people say "people change," the first thing I ask is: how often? And the conclusion is that we're in a constant state of flux, not in terms of time, but in the sheer frequency of our thoughts.

Our thoughts are the lifeline for change. This conclusion may have been heavily influenced by my recent rereading of [[The Power of Your Subconscious Mind - Joseph Murphy|Joseph Murphy's The Power of Your Subconscious Mind]] (I read this every time I'm in mama's office now. And yes, integrating more literature into my daily life is yet another subgoal in my journey of being more introspective. I fear btw that this subgoal, or perhaps even my entire quest for introspection, is circling me back to an identity I had during my adolescent years. Is it a bad thing though? I honestly don't think so).

# questions on thoughts
Where do our thoughts come from? What is the proportion of our organic thoughts to those influenced by external influences? Or this question itself flawed? Are all thoughts actually shaped by influences beyond ourselves, given that [[n - beings-in-the-world by philosopher martin heidegger|identities materialize only by being a part of this world?]] That [[n - the spyglass self|identities rely on other identities]], otherwise it would not have existed in the same way that [[n - we need names because we don't know who we are|labels and names don't exist if the object is the only one of its kind]]?

# it's our thoughts
The answer to these questions doesn't chip away from my standing on the ever-changing nature of identities. The constancy of change is intertwined with the constancy of thoughts birthed by our mind as we interact with life. 

Therefore, we change every time we [[humans can't live without thinking|think]].

---
Date: [[2023 May 30, Tue]]
Copies: 
Tags: #change #thinking #thoughts #identity #existence 
