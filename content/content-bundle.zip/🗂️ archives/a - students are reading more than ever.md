>*...college students engage with and consume more content than at any time in history. It just so happens that this content is delivered by a streaming service, video game or social media platform, not by a college instructor.*

---
Copies: https://hypothes.is/a/nqjXpAFfEe6odY_DwptEhw
Tags:  #internet #social-media #learning #reading #content/consumption