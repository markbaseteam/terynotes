> The Lord explained in a revelation to the Prophet Joseph Smith ‘that when ye are assembled together ye shall instruct and edify each other, that ye may know … how to act upon the points of my law and commandment’ [D&C 43:8]. But knowing ‘how to act’ isn’t enough. The Lord in the next verse said, ‘Ye shall bind yourselves to act in all holiness before me’ [D&C 43:9]. This willingness to take action on what we have learned opens the doors for marvelous blessings” (“The Blessings of General Conference,” Ensign or Liahona, Nov. 2005, 52).

some thoughts i have on this:

[[holy habits make the covenants path sustainable|this commandment is reminiscent of what was instructed to the nephites in moroni 6:4-5.]] to break it down:

in verse 4, it is indicated that three things kept the nephites on the path of their covenant and enabled them to flourish:

a) they consistently remembered and nourished themselves with the word of god
b) they actively sought opportunities for prayer
c) they highly valued the virtues of christ

these three points encompass the holy habits then listed in verse 5:
a) gathering together frequently
b) fasting
c) praying, and
d) discussing the welfare of each other's souls

the commandment to instruct and edify one another when we gather, in its apparent form, refers to attending and participating in sunday school classes and other church gatherings. but as we prepare for the Lord's second coming, we are called to build zion here on earth first. to truly accomplish that, we should engage in church-like interaction beyond just the first day of the week.

we are meant to create a community of like-minded individuals who come together as one in christ (zion). this entails supporting one another even outside of church, continuing to hold each other's hands after attending the sacrament together

---
Copies: https://hypothes.is/a/gssfIgRAEe6cvn_t5-LJNQ
Tags: #gathering #religion/lds/church #teach-one-another #unity #zion 