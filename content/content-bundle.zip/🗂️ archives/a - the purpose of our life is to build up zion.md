> “The purpose of our life should be to build up the Zion of our God, to gather the House of Israel, … store up treasures of knowledge and wisdom in our own understandings, purify our own hearts and prepare a people to meet the Lord when he comes. … “We have no business here other than to build up and establish the Zion of God. It must be done according to the will and law of God [see D&C 105:5], after that pattern and order by which Enoch built up and perfected the former-day Zion, which was taken away to heaven. … We, through our faithfulness, must prepare ourselves to meet Zion from above when it shall return to earth, and to abide the brightness and glory of its coming” (Teachings of Presidents of the Church: Brigham Young [1997], 111–12).

a couple things:

- as social creatures, human beings rely on establishing relationships with those around us. our existence begins within families, through the union of a mother and a father, and this pattern repeats throughout generations
- these communal relationships form the foundation for unity, creating a shared purpose and principles. any discord within these relationships can result in separation
- death serves as the most explicit form of separation: firstly, physical death separates the body from the spirit, and finally, spiritual death represents the separation of men from god.
- another explicit instance of separation found in the scriptures is the scattering of Israel. our current work involves gathering israel, which requires severing our ties with our brothers and sisters across the globe. this gathering process is vital in building the zion we are commanded to establish before the second coming of christ

[[n - the church is one body]]

---
Copies: https://hypothes.is/a/yUl3kARLEe6p9Ne0vi75jw
Tags: #zion #unity #religion/lds/church #singularity #human/humanity #gathering #scattering #separation #death/spiritual #death/physical #second-coming 