neurologists have discovered that when emotions and feelings are impaired, we lose the ability to make decisions. we have no signal of what to pursue and what to avoid. when we make decisions, we need a good measure of how good or bad something is, which emotions allow us to have.

---
Copies:
Source: [[b - Atomic Habits - James Clear]]
Tags: #decision/making #emotions #mind/emotional 
