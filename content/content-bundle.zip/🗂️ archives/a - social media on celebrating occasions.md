>*I was discussing with a friend that it'd almost be cooler to hire someone to take good pics with their phone and immediately post them during the event! They would post from their phone, tag people, and the event would spread on socials.*

1) now that i think about it (considering my perspective as someone whose parents have represented the bride or groom's side), i realize that professional photos hold significance in preserving the occasion in a formal manner within family albums. after all, a wedding is an inherently formal event. also, sharing these photos on social media at a later date serves as a good follow-up of the event even after its passing.

2) but your friends and family will do this for you willingly for free, no?

3) also, professional photos do have a distinct quality in that they are captured by skilled photographers who possess a profound understanding of the art

4) yet another fascinating anecdote on the impact of social media on our participation in events and the way we celebrate important milestones

---
Copies: https://hypothes.is/a/5MQ6zgNzEe6xcgMn1H2yZw
Tags: #social-media #wedding #taking/photos #engagement #capturing-moments