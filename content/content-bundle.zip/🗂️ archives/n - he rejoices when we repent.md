>13 And [[a soul is a great worth in the eyes of the lord|how great is his joy]] in the soul that repenteth!

---
Copies:
Source: Doctrine and Covenants 18
Tags: #joy #repentance #soul