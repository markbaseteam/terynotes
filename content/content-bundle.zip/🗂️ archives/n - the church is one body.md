1 Corinthians 12:12-14 emphasizes the idea that all individuals, regardless of their background or status, are [[the lord and his father are one in purpose|united as one body through the Spirit of Christ]]. Paul teaches the importance of unity and care for one another within this body to avoid any divisions or schisms. [[n - much of our belonging comes from our contributions|It also emphasizes the interconnectedness of all individuals within the body, such that if one member suffers, all members suffer, and if one member is honored, all members rejoice]].

---
Copies:
Source: [[The Doctrine of Belonging - Elder D. Todd Christofferson]]
Tags: #scriptures/Bible/new-testament #scriptures/Bible/characters/Paul #zion #community #unity #family #religion/lds/church #Jesus_Christ #belongingness #connection #interconnection #singularity