>*My emphasis will be on the Book of Mormon, because the Savior taught the sacrament ordinances to the Nephites almost immediately after he came to them, not long after he had instituted the ordinances among his Jerusalem disciples. Therefore, we have a close parallel between the two experiences.*

i wonder if the sacrament ordinance is exclusively tied to the sabbath day. historically, the sabbath day has not always fallen on the first day of the week (and in certain denominations of christianity, it continues to differ from the first day of the week). so it is plausible that the frequency of administering the sacrament is not rigidly fixed as well, and it remains open to the possibility that the day of sabbath itself influences the observance of this sacred ordinance

---
Copies: https://hypothes.is/a/0CUIEgFKEe6v8OdxSPwIgA
Tags: #sacrament #sabbathday #sunday #temple/ordinance 