>*Actually, as Davidson argues, multitasking helps us see more and do more, and experience texts and tasks in different ways. There’s no evidence that anyone ever was deeply reading for hours on end with no interruptions. All we have are claims from Plato saying that writing is going to kill our ability to memorize. Our minds have always been wandering; we’ve always been distractible. We’ve always been doodling on the sides of pages, or thinking about our lunch, or stopping to converse with someone. Now we just have distraction that’s more readily available and purposefully attuned to distracting us — like popup ads, notifications; things that quite literally fly across your screen to distract you. But the fact that we have students who have grown up with those and have trained themselves to deal with those in such interesting ways is something that I think we should bring into the classroom and be talking about and critically thinking about*

1) the point that multitasking can offer different experiences with texts and tasks is interesting to me. initially, the comparison between multitasking and single-tasking seems like a clear distinction between what is beneficial (focus) and what is detrimental (distraction)

2) taking a bold stance, i would venture to say that there exists a significant number of individuals who engage in deep work, which is perhaps one of the most profound pursuits throughout human history. after all, most of us have experienced a state of flow at least once, to some extent, and our brains subconsciously crave this state of heightened focus and productivity

3) this observation all the more underscores the rarity of deep work in a world that is perpetually plagued by distractions

here is one of my notes from [[b - Deep Work - Cal Newport|deep work by cal newport]]:

the connection between depth and meaning in human experience is undeniable. whether approached from the perspectives of neuroscience, psychology, or philosophy, there appears to be a profound correlation between engaging in deep, meaningful activities and a sense of fulfillment. this suggests that our species may have evolved to thrive in the realm of deep work and purposeful engagement

---
Copies: https://hypothes.is/a/TeyKxgFlEe6l87seAkf0KA
Tags: #task/multitasking #work/deep #flowstate #distractions 