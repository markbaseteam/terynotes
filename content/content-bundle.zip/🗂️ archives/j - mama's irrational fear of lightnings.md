When I entered the kitchen with my dirty dishes in hand at 2 in the morning, I discovered the living room and kitchen illuminated as if it were daytime. [[👩🏻 Dela Cuadra, AURELIA Cordero|Mama]] was sprawled on the couch, engrossed in her phone, wearing a wide smile.

I've caught her a few times in the past, lingering in the living room during late hours, but my assumptions never extended beyond "she just couldn't sleep." But tonight, a super typhoon looms, and I've heard snippets of news from my sisters and others about its predicted strength and the possibility of flooding.

I had done my laundry on the day the typhoon was expected. I remember waking up that morning, filled with excitement to sort through my dirty clothes and dedicate a good 2 to 4 hours hand-washing each item in the hamper.

Incidentally, I had just watched a [video from NHK Japan](https://youtu.be/Z4yKj-GU8uw) featuring an elderly chef who thanked the sun every morning upon waking up. Lately, I've developed a fondness for pleasant weather. It's a shame to admit that during my adolescent years, I never truly appreciated the sun’s power to uplift, as I was consumed by…well, hormones among other things. Now, I pout whenever I don't glimpse a blue sky through my window.

Anyways, a few moments ago, the lightning and thunder became so intense that the power kept flickering. It would briefly return after a couple of minutes, but it posed a significant threat to a peaceful night's sleep.

So, I assumed mama woke up due to the commotion and couldn't fall back asleep. Even though she didn't explicitly mention it, mama has always been dog-scared of lightning. Whenever we heard thunderous roars that rattled our very existence, she would rush towards the windows, hastily closing the curtains.

Initially, we interpreted this as her show-don’t-tell approach in parenting, so that it’s crystal clear to the kids: lightning = bad. But as we grew older, we began to witness her performing this ritual even when the lightning was ridiculously far from our house. We’re talking miles so it’s barely even audible. And as a response, we would engage in a bit of playful protest, challenging the extent of her irrational fear. But all she does after a whimsical, childlike sprint to the curtains is change the topic.

On my way back to my bedroom after the brief kitchen visit, she held her phone up to my face and exclaimed, "Look at this! In LA, there's a drug that's turning people into zombies!"

So secretly, I wished for another thunderous roar, a good way to wrap-up the remains of the day with a hearty laughter, but the rest of the night was quiet. I'm certain mama eventually returned to her own bed.

---
Date: [[2023 May 31, Wed]]
Copies: [Substack - Mama's Irrational Fear of Lightning](https://open.substack.com/pub/somerhapsodies/p/coming-soon?r=27zn2f&utm_campaign=post&utm_medium=web)
