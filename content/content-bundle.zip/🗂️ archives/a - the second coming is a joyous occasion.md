> “The great day of the Lord” (D&C 43:17) refers to Jesus Christ’s Second Coming and the commencement of the Millennium. God commanded His servants to declare repentance to prevent His children from being destroyed with the wicked when the Savior returns. While some will give heed and repent, others will ignore and reject the voice of the Lord’s servants. Therefore, the Lord raises the voice of warning to repent through a variety of means: His servants, the ministering of angels, His own voice, and even the destructive power of nature.

- a powerful reminder that the second coming of jesus christ is a joyous occasion, which is why it's symbolized by a marriage feast:

"there's a marriage coming! It's gonna be great!" - dr. camille f. olson ([https://open.spotify.com/episode/0vGHSOKivLW2MkDLwecsH2?si=73ef0cee0a3c47c8](https://open.spotify.com/episode/0vGHSOKivLW2MkDLwecsH2?si=73ef0cee0a3c47c8))

- the prominence of the message of repentance stems from the fact that the gospel of jesus christ is a gospel of salvation brought upon by repentance, which is closely tied to humility. our recognition of our own nothingness leads us to rely on the boundless everythingness of our god to be perfected one day. (Doctrine and Covenants 6:9, 11:9, Doctrine and Covenants Student Manual 11)

[[n - say nothing but repentance]]

---
Copies: https://hypothes.is/a/CDqm3ARGEe6kH-8RujugGw
Tags: #parable/the-marriage-feast #second-coming #repentance #salvation #humility #gospel 