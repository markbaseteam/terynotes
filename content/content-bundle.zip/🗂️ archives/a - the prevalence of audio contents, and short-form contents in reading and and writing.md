>*I always like to point to a text that changed my thinking about this question, and that’s Kathleen Yancey’s “Writing in the 21st Century.” It basically states that students are writing more than ever before. If you were to challenge a group of students (which I have) to document how many text messages, TikTok, IG posts, Facebook posts, tweets, emails they send out in a day, the sheer volume of writing is staggering. Why we don’t value that writing in academia is the question for me.*

interesting point! some other things in my head:

1) in addition to our increased writing endeavors, we've also been engaging in extensive reading as well, but our reading material has evolved beyond books, encompassing the plethora of content available in the vast expanse of cyberspace

2) and while the quantity of reading has expanded significantly, it is equally intriguing to recognize that the nature of these texts has shifted towards shorter formats—tweets, ig post captions, microblogs, etc

3) AND lastly, the act of reading has swiftly evolved into the realm of listening, with the emergence of podcasts, audiobooks, listenable videos, and similar forms of content consumption

---
Copies: https://hypothes.is/a/EcgllAFiEe6l53t4oslk4Q
Tags: #content/short-form #reading #writing #content/audio #content/audio/audiobooks #content/audio/podcasts #social-media 