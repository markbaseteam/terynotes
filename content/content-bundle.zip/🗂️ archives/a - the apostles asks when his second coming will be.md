>Jesus Christ met with His disciples on the Mount of Olives during His last week in mortality. At that time He prophesied of the destruction of the temple in Jerusalem, and His disciples asked when that destruction would occur and when He would return to the earth (see Joseph Smith—Matthew 1:2–4). In response the Lord revealed the signs that would occur shortly after His death and those that would precede His Second Coming. He repeated this prophecy to His Saints in the latter days, as recorded in Doctrine and Covenants 45:16–59.

---
Copies: https://hypothes.is/a/Hs2Z7gRHEe6rnY9-4_I0Fg
Tags: #second-coming #12-apostles #Jesus_Christ/mortality