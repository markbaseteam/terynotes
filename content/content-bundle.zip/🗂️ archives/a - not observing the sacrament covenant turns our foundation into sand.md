>*Just as proper baptism was the beginning of the building upon the rock, so was the covenant of the sacrament. While the ordinance of baptism was a one-time, long-term commitment, the sacrament serves as a weekly opportunity to keep a proper foundation, the rock of Christ, under our quest for eternal life and to build upon it. For those who fail to observe their sacrament covenants, their foundation becomes one of sand and leads to an entrance into the gates of hell (18:13).*

---
Copies: https://hypothes.is/a/sWHlWgFcEe6OhVtuU4PE8Q
Tags: #sacrament #foundation #covenant/keeping 