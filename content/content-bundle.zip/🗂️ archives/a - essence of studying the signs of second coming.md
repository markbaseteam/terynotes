> “What shall be the sign of thy coming, and of the end of the world?” (Matthew 24:3). Jesus Christ’s teachings found in Matthew 24:3–51 were greatly expanded through the inspired translation made by the Prophet Joseph Smith, as found in Joseph Smith—Matthew 1:4–55 (in the Pearl of Great Price). Several sections in the Doctrine and Covenants also help to explain the events of the last days and how God’s children can prepare for them (examples include D&C 29; 38; 45; 63; 84; 88; 101; 133).

i wonder then what the true essence of studying the signs of the second coming of jesus christ if it isn't to merely pinpoint the exact date and time, but rather to inspire us to prepare in the present, to draw closer to him, so that we may have no regrets when the day arrives

---
Copies: https://hypothes.is/a/32lpqARHEe66af--uI5pDA
Tags: #second-coming/preparation 