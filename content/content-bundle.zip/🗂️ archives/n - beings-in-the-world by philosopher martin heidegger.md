martin heidegger argues that we, as human beings, are always engaged with our surroundings and seeking to [[our need for a shared understanding of the world|make sense of our existence]] within them. this is reminiscent of what [[b - Atomic Habits - James Clear|james clear said in his book, atomic habits]], that [[life is predictive]], that we are constantly scanning our environment to cue us for our next action.

---
Copies:
Tags: #environment #society #human/humanity #action #behavior #identity #existence 