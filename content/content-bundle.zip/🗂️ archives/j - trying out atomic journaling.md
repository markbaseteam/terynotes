# devising a new journaling system
Last night, I was [[writing is the medium of thinking|thinking (writing, really)]] of an enhancement to my journaling system that would blur the lines between my notes and my journal logs so that I can link them together in a hopefully more seamless way where the things that I'm learning about (permanent notes) and my own experiences, thoughts and feelings, and memories (journal logs) are more resembling of each other and resurfacing the same way in my personal knowledge management system.

I get that this is where fleeting notes come in, or at least I do now that I have come across these two blog posts which almost effectively solves the same question I have regarding Zettelkasten and journaling.

These are the articles I read:
- [Atomic Journal: A Streamlined Approach](https://mindfulnotes.substack.com/p/atomic-journaling-a-streamlined-approach)
- [Stream of Consciousness to Atomic Notes: A Powerful Note-Taking Workflow](https://themindfulteacher.medium.com/stream-of-consciousness-to-atomic-notes-a-powerful-note-taking-workflow-2c18fafe2446)

## putting a filter on the stream of consciousness
Interestingly, I had previously considered implementing a similar approach, but I had my reservations. Primarily, I was concerned that if my journal entries became standalone notes, I would be filtering my brain's output and only logging events I deemed important for future reference. As humans, we are fallible, and predicting which events will be relevant in the future is challenging.

## eliminating tangents on the atomic journaling system
Subsequently, this approach would eliminate tangents in my entries, which often contain valuable information that I may want to refer back to.

For instance, while discussing my lack of homework completion in an entry, I might incidentally mention missing my boyfriend. With atomic journaling, I would think twice about including this tangent, as it may compromise the atomicity of the entry. However, in the distant future, examining patterns in my moods, the tangent about missing my boyfriend could provide valuable insight into what influences my behavior. Tangents, after all, reflect the multifaceted nature of our thoughts as various ideas flicker through our minds.

The rigid structure of atomic journaling could strip my journal logs of these fleeting thoughts, which I believe are crucial clues and indicators of topics I would want to explore and study in the future.

## differing objectives between atomic journaling and traditional journaling
The last one would be that the objectives of long-form journaling differ from those of atomic journaling. Atomic journaling, as an appendix to the Zettelkasten system, focuses on recording events and thoughts for future retrieval, requiring each log to have a specific topic. In contrast, long-form journaling allows for more free-flowing expression without the need for a specific topic. [[writing is the medium of thinking|The act of writing itself is the main goal.]] Even if the entry consists of a stream of thoughts that may not make immediate sense, the act of writing the entry is considered a success. If later converted into atomic journal logs, either nothing would be converted or only a fraction of the original entry would remain.

# trying out atomic journaling
So why am I still considering atomic journaling? What am I doing differently this time? What benefits am I hoping to gain from adopting this new system?

The simplest reason is that trial and error is rarely a wrong approach. By trying out this system, I aim to fully understand and experience the nuances it brings to my personal knowledge management system.

The three caveats I initially listed, although seemingly valid, are merely conjectures that formed from reading those two blog posts.

The other reason is that I believe that atomic journaling could serve as the foundation upon which I build my journaling system. By starting to use this system now, I can customize and tailor it to suit my specific needs.

So with this, I honestly think I'm off to a great start.

---
Date: [[2023 May 30, Tue]]
Copies: https://open.substack.com/pub/somerhapsodies/p/trying-out-atomic-journaling?r=27zn2f&utm_campaign=post&utm_medium=web
Tags: #log/journal #journal-keeping #writing #thinking #thought/pattern #zettelkasten/fleeting-notes #zettelkasten/atomicity #tangent #stream-of-consciousness #sense-making 