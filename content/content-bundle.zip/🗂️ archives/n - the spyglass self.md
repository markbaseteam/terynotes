our identities are shaped by observing ourselves from the perspectives of the people around us. our personality is a performance of ourselves through other people.

---
Copies: 
Source: The Prism Substack
Tags: #self #identity #performance #perspective #personality

