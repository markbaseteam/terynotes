>The signs of the Lord’s Second Coming may be divided into two main categories: 
>
>(1) signs that are part of the Restoration of the gospel and its eventual expansion throughout the world and 
>
>(2) signs that are part of the increase of evils and the calamities and judgments to come upon the world. Some of the signs and events of the Second Coming that are described in Doctrine and Covenants 45:16–59 include the following: 
>
>Gentiles and Jews will be gathered (see D&C 45:25, 30, 43) “Wars and rumors of wars, and the whole earth shall be in commotion” (D&C 45:26) 
>
>The fulness of the gospel will be restored (see D&C 45:28) “A desolating sickness shall cover the land” (D&C 45:31) 
>
>The Lord’s disciples “shall stand in holy places, and shall not be moved” (D&C 45:32) 
>
>“Earthquakes … in divers places, and many desolations” (D&C 45:33) 
>
>“Signs and wonders … shown forth in the heavens above, and in the earth beneath” (D&C 45:40) 
>
>“The sun shall be darkened, and the moon be turned into blood” (D&C 45:42) 
>
>The Lord will come “clothed with power and great glory; with all the holy angels” (D&C 45:44) 
>
>“Saints that have slept shall come forth” (D&C 45:45) 
>
>The Lord will appear on the Mount of Olives and converse with the Jews (see D&C 45:48, 51–53)

---
Copies: https://hypothes.is/a/a2K48gRHEe6HLos85ws8CQ
Tags: #second-coming/preparation #gathering 