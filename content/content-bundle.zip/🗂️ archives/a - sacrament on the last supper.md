>*Jesus celebrated the Passover meal with his beloved twelve apostles at the end of his three-year ministry. At this Last Supper, he initiated the ordinance of the sacrament. All three of the synoptic Gospels bear record of this event, which occurred on the evening of the first day of unleavened bread.*

1) is this the first instance in history when Jesus administered the sacrament to the Twelve?

2) if so, why did He choose to do so only towards the end of his earthly life?

3) it's fascinating to ruminate how the passover and the sacrament coincided on this particular occasion. typically, we do not associate the sacrament with meals (of course this is not to reduce the whole event of passover to simply gathering and eating)

---
Copies: https://hypothes.is/a/CotaIAFFEe6tzxdJI47tHA
Tags: #Jesus_Christ #12-apostles #sacrament #the-last-supper #passover