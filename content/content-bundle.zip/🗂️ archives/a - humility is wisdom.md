> The Doctrine and Covenants provides some interpretation of this parable, explaining that the blessings promised to those who are wise include the promise to be with the Lord during His Millennial reign on earth (see D&C 45:56–59). The wise are described as those who “have received the truth, and have taken the Holy Spirit for their guide, and have not been deceived” (D&C 45:57).

humility is wisdom: [[n - education is a gradual realization of our ignorance]]

---
Copies: https://hypothes.is/a/SSm-IgRKEe6HNJNwocSjoA
Tags: #humility #ignorance #wisdom 

