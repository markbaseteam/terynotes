>*And he took bread, and gave thanks, and brake it, and gave unto them, saying, This is my body which is given for you: this do in remembrance of me.*

it's interesting that the accounts of matthew and mark do not include the specific mention of the remembrance aspect in relation to the ordinance they describe. luke and mark are both not part of the original 12 apostles, but the remembrance part of this ordinance is such a crucial detail.

---
Copies: https://hypothes.is/a/AWPULgFIEe6OX6MgSWjT0g
Tags: #remembrance #sacrament #the-last-supper #scriptures/Bible/characters/luke #scriptures/Bible/characters/matthew #scriptures/Bible/characters/mark #Jesus_Christ #covenant 