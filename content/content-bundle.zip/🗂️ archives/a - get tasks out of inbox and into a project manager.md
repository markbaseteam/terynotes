>I currently inhabit four professional roles: writer, teacher, researcher, and director of graduate studies for my department. For each of these roles, I set up a Trello board that includes a column for: things I’m working on actively, thing I’m waiting to hear back about from someone else,  things on my “back burner” that I’m not yet ready to tackle, and  a list of ambiguous or complicated things that I need to spend some time on figuring out. Every email I receive immediately gets moved to one of these columns in one of my Trello boards.

---
Copies: https://hypothes.is/a/6u8EzAO2Ee62oFe8sDmrJg
Tags: #email/management/inbox-zero #kanban-board #project/management 