>*"The most invisible form of wasted time is doing a good job on an unimportant task."*

1) excelling at trivial tasks showcases unrecognized skills

2) must every action we undertake contribute to important things? shouldn't we dedicate some time to activities that bring us joy?

3) is wasted time even a concern if you don't know where you're going in life?

i remember [[n - you're only lost if you have somewhere to be|a scene from alice in wonderland]] where alice comes to a fork in the road and asks the cheshire cat which path to take. the cheshire cat asks where she's going and she replies, "i don't know." the cat then response, "then it doesn't matter."

in a similar vein, wandering about on the different forks in the road compels us to explore options visible to us that may seem inconsequential because they don't count towards any objective or purpose, because there's nothing set yet (or ever)

---
Copies: https://hypothes.is/a/etT0kgN3Ee6nUrtKTMafDQ