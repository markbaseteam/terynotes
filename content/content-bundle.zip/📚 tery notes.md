# quick introduction
Hey there, I'm Tery Gasmen. Thanks for being here. I've made several attempts to elect my own space on the internet for quite some time now, but I've yet to strike that good-enough balance that aligns with my ambitions.

With this perpetual urge to broaden my digital footprint (sidebar: We're drowning in a sea of data, courtesy of those tech giants. Just by simply existing in cyberspace, they've managed to create voodoo dolls of us in their opulent conference rooms. So, in a twist of fate, I've decided to relinquish my data privacy anxiety (bordering on paranoia), and feed them with even more data which relentless predictions will keep nudging me to embody this "Tery" they've conjured up), I'm once again resurrecting [tery notes](https://terynotes.markbase.xyz/) on the face of the web, with this version a slight upgrade through partially catering to the needs of others (that's vague, but let's keep it at that for the meantime). By doing so, I hope this project will endure in the minds of other people, even after my personal motivation on it sours.

Feel free to look around. My notes are an amalgamation of subjects that capture my interest and inspire to me to wake up each morning with vigor. And with that, let me stress that all the content you encounter here are STUDY notes, thus remaining susceptible to frequent modifications, updates, and potential abandonment. Leave your judgments at the door and enjoy!

Check out navigation to continue: [[🧭 directories]]

---
# this month
- books i'm reading
- habits i'm building
- projects i'm working on

---
# links
- published annotations - [https://hypothes.is/users/teryyyg](https://hypothes.is/users/teryyyg)
- journal - [https://somerhapsodies.substack.com/](https://somerhapsodies.substack.com/)
- goodreads - [https://www.goodreads.com/user/show/164565376-tery-gasmen](https://www.goodreads.com/user/show/164565376-tery-gasmen)
- tip jar - [https://ko-fi.com/terynotes](https://ko-fi.com/terynotes)
