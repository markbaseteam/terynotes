# index
## focus
- [[a - multitasking and flow state]]
- [[a - undertaking unimportant tasks]]
## learning
- [[a - learning is influenced by social dynamics]]
- [[a - student engagement in learning]]
- [[n - the whiteboard effect and collaborative deep work]]
## reading and writing
- [[a - students are reading more than ever]]
- [[a - the prevalence of audio contents, and short-form contents in reading and and writing]]
## social media
- [[a - social media on celebrating occasions]]
## theology
- [[a - sacrament on the last supper]]
- [[a - not observing the sacrament covenant turns our foundation into sand]]
- [[a - prepare our bodies for the sacrament]]
- [[a - luke records the importance of remembrance in the sacrament]]
- [[a - did the apostles fail to grasp the essence of sacrament in the last supper]]
- [[a - the day and frequency of the ordinance of sacrament]]
- [[a - the purpose of our life is to build up zion]]
- [[a - humility is wisdom]]
- [[a - what are the holy places]]
- [[a - the signs of second coming]]
- [[a - essence of studying the signs of second coming]]
- [[a - the apostles asks when his second coming will be]]
- [[a - the second coming is a joyous occasion]]
- [[a - we are commanded to instruct and edify each other]]
- [[a - we are to bind our feelings together that we may become one]]
- [[a - the extent of the gift of revelation]]
## productivity
- [[a - hold office hours]]
- [[a - get tasks out of inbox and into a project manager]]
- [[a - use meeting scheduling services]]
## journaling
- [[j - trying out atomic journaling]]

---
# journal entries
- [[j - mama's irrational fear of lightnings]]
- [[j - we change every time we think]]
- [[j - trying out atomic journaling]]

# annotations
- [[a - student engagement in learning]]
- [[a - students are reading more than ever]]
- [[a - learning is influenced by social dynamics]]
- [[a - sacrament on the last supper]]
- [[a - not observing the sacrament covenant turns our foundation into sand]]
- [[a - prepare our bodies for the sacrament]]
- [[a - luke records the importance of remembrance in the sacrament]]
- [[a - did the apostles fail to grasp the essence of sacrament in the last supper]]
- [[a - the day and frequency of the ordinance of sacrament]]
- [[a - multitasking and flow state]]
- [[a - the prevalence of audio contents, and short-form contents in reading and and writing]]
- [[a - undertaking unimportant tasks]]
- [[a - social media on celebrating occasions]]
- [[a - hold office hours]]
- [[a - get tasks out of inbox and into a project manager]]
- [[a - use meeting scheduling services]]
- [[a - the purpose of our life is to build up zion]]
- [[a - humility is wisdom]]
- [[a - what are the holy places]]
- [[a - the signs of second coming]]
- [[a - essence of studying the signs of second coming]]
- [[a - the apostles asks when his second coming will be]]
- [[a - the second coming is a joyous occasion]]
- [[a - we are commanded to instruct and edify each other]]
- [[a - we are to bind our feelings together that we may become one]]
- [[a - the extent of the gift of revelation]]

# notes
- [[n - you're only lost if you have somewhere to be]]
- [[n - the whiteboard effect and collaborative deep work]]
- [[n - beings-in-the-world by philosopher martin heidegger]]
- [[n - the spyglass self]]
- [[n - we need names because we don't know who we are]]
- [[n - education is a gradual realization of our ignorance]]
- [[n - emotions allow us to make decisions]]
- [[n - he rejoices when we repent]]
- [[n - much of our belonging comes from our contributions]]
- [[n - say nothing but repentance]]
- [[n - the church is one body]]

# books
- [[b - Deep Work - Cal Newport]]
- [[b - How to Win at College - Cal Newport]]
- [[b - Atomic Habits - James Clear]]

# tv
- [[tv - pierce's wisdom on man's limitations]]
